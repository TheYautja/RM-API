

class Character 
{
    int id;
    String name;
    String status;
    String species;
    String type;
    String gender;
    Map? origin;
    Map? location;
    String image;
    List? episode;
    String url;
    String created;

    Character({
        required this.id,
        required this.name,
        required this.status,
        required this.species,
        required this.type,
        required this.gender,
        this.origin,
        this.location,
        required this.image,
        this.episode,
        required this.url,
        required this.created,
    });

}
