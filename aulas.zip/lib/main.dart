import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: LandingScreen(),
    )
  );
}



class LandingScreen extends StatelessWidget 
{
   @override
     Widget build(BuildContext context)
     {
        return Scaffold(
            
            appBar: AppBar(
                title: Text("appbar máxima"),
            ),

            body: ListView(
                children: [
                    ButtonImage("assets/images/characters.png", "personagens"),
                    ButtonImage("assets/images/locations.png", "locais"),
                    ButtonImage("assets/images/episodes.png", "episodios"),
                ]
            ),


        );
     } 
}




class ButtonImage extends StatelessWidget
{

    String imgPath;
    String btnText;

    ButtonImage(imgPath, btnText){
        this.imgPath = imgPath;
        this.btnText = btnText;
    }

    @override
      Widget build(BuildContext context) {
        return Column(
            children: [

                GestureDetector(
                    onTap: () {}, 
                    child: CircleAvatar(child: Image.asset(imgPath),
                    radius: 80)),

                Center( 
                    child: Text(btnText, style: TextStyle(fontSize: 20)),
                ),

            ],
        );
      }
}
